console.log("My first console project");

            var first_name = "Ranbir";
            var last_name = "Kapoor";

/*
Concatenate the first name and the last name to print the full name of the person on the console. 

Type the line: "first_name.concat(last_name)"
*/
            var full_name =  ;
            console.log(full_name);

            var a = 10;
            var b = 5;
/*
Create a variable named add and store the addition value of a and b in that variable.

Type: var add = a + b

Then, print the variable to display the addition value

Type: console.log(add)
*/
            var add =   ;
            console.log( );

/*
Create a variable named sub and store the subtraction value of a and b in that variable.

Type: var sub = a - b

Then, print the variable to display the subtraction value

Type: console.log(sub)
*/
            var sub =   ;
            console.log( );

/*
Create a variable named multiple and store the multiplication value of a and b in that variable.

Type: var multiple = a * b

Then, print the variable to display the multiplication value

Type: console.log(multiple)
*/
            var multiple =   ;
            console.log();

            var divide = a / b ;
            console.log(divide);